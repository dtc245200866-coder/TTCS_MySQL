# Báo cáo Index Trade-off – SmartFactory

`idx_fat_covering` gồm `(sensor_id, recorded_at, temperature, humidity, status)`.
Hai cột đầu phục vụ điều kiện lọc của Dashboard; ba cột còn lại được thêm để
có thể biến truy vấn thành Covering Index. Với bảng SensorLogs có lưu lượng ghi
cao, thiết kế này làm secondary index lớn hơn và tăng chi phí duy trì.

Mỗi INSERT vào InnoDB phải cập nhật các secondary index liên quan. Khi entry
của index lớn, lượng dữ liệu cần ghi và số page cần quản lý cũng tăng. Trong
trường hợp page đầy, B-Tree có thể phải thực hiện page split. Tuy nhiên, không
chính xác nếu nói mỗi INSERT đều “sắp xếp lại toàn bộ cây B-Tree”.

Giải pháp là thay Fat Index bằng:

```sql
CREATE INDEX idx_lean_search
ON SensorLogs(sensor_id, recorded_at);
```

Index mới vẫn hỗ trợ lọc theo `sensor_id` và khoảng thời gian `recorded_at`.
MySQL sau đó có thể phải lookup bảng để lấy `temperature`, `humidity` và
`status`, nên lợi ích Covering Index không còn.

Đây là sự đánh đổi giữa Read và Write: giảm kích thước và write overhead của
secondary index để đổi lấy một bước table lookup khi SELECT. Các con số như
“INSERT nhanh 5 lần” hoặc “giảm 70%” chỉ nên ghi nếu benchmark thực tế chứng
minh được.

| Chỉ số | Trước | Sau |
|---|---:|---:|
| Index size (MB) | ___ | ___ |
| Data size (MB) | ___ | ___ |
| Total size (MB) | ___ | ___ |
| EXPLAIN / Extra | ___ | ___ |

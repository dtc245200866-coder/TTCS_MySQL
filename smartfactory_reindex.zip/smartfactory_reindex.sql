-- smartfactory_reindex.sql
CREATE DATABASE IF NOT EXISTS smartfactory_db;
USE smartfactory_db;

CREATE TABLE IF NOT EXISTS SensorLogs (
    log_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    sensor_id INT NOT NULL,
    recorded_at DATETIME NOT NULL,
    temperature DECIMAL(5,2),
    humidity DECIMAL(5,2),
    status VARCHAR(20)
);

SHOW INDEX FROM SensorLogs;
SHOW TABLE STATUS LIKE 'SensorLogs';

SELECT TABLE_NAME,
       ROUND(DATA_LENGTH/1024/1024,2) AS data_size_mb,
       ROUND(INDEX_LENGTH/1024/1024,2) AS index_size_mb,
       ROUND((DATA_LENGTH+INDEX_LENGTH)/1024/1024,2) AS total_size_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'SensorLogs';

-- EXPLAIN trước tối ưu
EXPLAIN
SELECT temperature, humidity, status
FROM SensorLogs
WHERE sensor_id = 105 AND recorded_at >= '2026-06-20';

-- Xóa Fat Index
ALTER TABLE SensorLogs DROP INDEX idx_fat_covering;

-- Tạo Lean Index
CREATE INDEX idx_lean_search
ON SensorLogs(sensor_id, recorded_at);

SHOW INDEX FROM SensorLogs;

-- EXPLAIN sau tối ưu
EXPLAIN
SELECT temperature, humidity, status
FROM SensorLogs
WHERE sensor_id = 105 AND recorded_at >= '2026-06-20';

-- Đo dung lượng sau tối ưu
SHOW TABLE STATUS LIKE 'SensorLogs';

SELECT TABLE_NAME,
       ROUND(DATA_LENGTH/1024/1024,2) AS data_size_mb,
       ROUND(INDEX_LENGTH/1024/1024,2) AS index_size_mb,
       ROUND((DATA_LENGTH+INDEX_LENGTH)/1024/1024,2) AS total_size_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'SensorLogs';

-- Không tự ghi mức giảm 70% nếu chưa benchmark dữ liệu thực tế.

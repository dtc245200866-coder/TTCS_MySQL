# AI Prompt Log – SmartFactory

## Prompt 1 – Fat Index
**Prompt:** Vì sao index `(sensor_id, recorded_at, temperature, humidity, status)`
làm tăng Storage và Write Penalty?

**Tóm tắt:** Thêm nhiều cột làm secondary-index entry lớn hơn, cần nhiều page
hơn và làm tăng lượng dữ liệu phải duy trì khi ghi.

## Prompt 2 – Write Penalty
**Prompt:** INSERT vào InnoDB có nhiều secondary index xảy ra điều gì?

**Tóm tắt:** INSERT phải cập nhật clustered index và các secondary index liên
quan. Entry lớn làm tăng chi phí ghi/I/O; khi page không đủ chỗ có thể xảy ra
page split. Không phải toàn bộ B-Tree bị sắp xếp lại sau mỗi INSERT.

## Prompt 3 – Covering Index
**Prompt:** Vì sao Fat Index có thể tạo Covering Index và Lean Index thì không?

**Tóm tắt:** Fat Index chứa cả các cột được SELECT nên MySQL có thể lấy dữ liệu
ngay từ index và có thể hiện `Using index`. Lean Index chỉ chứa cột lọc, nên
thường phải lookup row trong bảng để lấy các cột còn lại.

## Prompt 4 – Byte Calculation
**Prompt:** So sánh kích thước BIGINT, INT, DATETIME, DECIMAL và VARCHAR khi
đưa vào secondary index.

**Tóm tắt:** Các kiểu dữ liệu có kích thước lưu trữ khác nhau; VARCHAR phụ thuộc
dữ liệu thực tế. Kích thước index thực tế còn có record/page overhead và
thông tin định vị row, nên không nên tính Index Length chỉ bằng phép cộng đơn
giản.

## Prompt 5 – Bảng ít ghi
**Prompt:** Nếu bảng Countries gần như không ghi nhưng đọc rất nhiều, Covering
Index có còn xấu không?

**Tóm tắt:** Không nhất thiết. Khi write rất ít, write penalty nhỏ hơn. Nếu
Covering Index giúp truy vấn đọc tránh table lookup thì chi phí Storage có
thể là đánh đổi hợp lý. Cần đánh giá theo workload và benchmark.

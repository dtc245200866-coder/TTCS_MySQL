# AI Prompt Log – QuickFeed Index Optimization

## Prompt 1 – Cardinality và Index

**Prompt:**
Trong MySQL, cardinality của một cột là gì? Vì sao các cột BOOLEAN
hoặc cột chỉ có vài giá trị như Active/Inactive, Nam/Nữ thường không phải
ứng viên tốt cho B-Tree Index? Giải thích bằng ví dụ bảng có hàng triệu dòng.

**Tóm tắt kết quả:**
Cardinality thể hiện mức độ đa dạng của giá trị trong một cột. Cardinality
thấp nghĩa là nhiều dòng có cùng giá trị. Khi một điều kiện WHERE trả về
phần lớn bảng, việc đọc index rồi truy cập các row có thể tốn hơn Full Table
Scan, nên Optimizer có thể không sử dụng index.

## Prompt 2 – TEXT và B-Tree

**Prompt:**
Trong MySQL, nếu tạo B-Tree Index trên cột TEXT bằng prefix 255 ký tự,
điều này ảnh hưởng thế nào đến RAM, disk và Query Optimizer? Khi nào nên
dùng FULLTEXT thay thế?

**Tóm tắt kết quả:**
Index cần không gian lưu trữ và bộ nhớ đệm khi được sử dụng. Prefix index
trên TEXT có thể lớn khi bảng có nhiều dòng. B-Tree phù hợp với các truy
vấn tìm kiếm theo giá trị/range phù hợp với index, còn tìm kiếm từ khóa
toàn văn thường phù hợp hơn với FULLTEXT.

## Prompt 3 – INSERT và B-Tree

**Prompt:**
Điều gì xảy ra ở tầng vật lý khi INSERT một dòng vào InnoDB có nhiều
secondary index? Vì sao nhiều index làm INSERT chậm hơn?

**Tóm tắt kết quả:**
Ngoài clustered index của PRIMARY KEY, các secondary index cũng phải được
cập nhật khi thêm dòng. Việc cập nhật có thể liên quan đến tìm vị trí trong
B-Tree, thay đổi page và trong một số trường hợp phải split page. Nhiều
secondary index vì thế làm tăng write amplification và chi phí I/O.

## Prompt 4 – Query Optimizer

**Prompt:**
Tại sao SELECT * FROM Posts WHERE is_visible = 1 có thể dùng Full Table
Scan thay vì idx_is_visible nếu 99% dữ liệu có is_visible = 1?

**Tóm tắt kết quả:**
Nếu điều kiện trả về gần như toàn bộ bảng, index không lọc được đủ dữ liệu.
Optimizer có thể chọn Full Table Scan vì đây là phương án có chi phí ước
tính thấp hơn.

## Prompt 5 – Archive Table

**Prompt:**
Nếu bảng chỉ dùng để lưu trữ, rất ít INSERT và gần như không UPDATE/DELETE,
nhiều index có còn là vấn đề không?

**Tóm tắt kết quả:**
Chi phí ghi giảm đáng kể nếu bảng hầu như không có thao tác ghi. Tuy nhiên,
index vẫn tiêu tốn disk và có thể cần RAM/cache khi truy vấn. Vì vậy nhiều
index không còn là "thảm họa write" như bảng OLTP nhiều INSERT, nhưng vẫn
cần đánh giá theo các truy vấn thực tế.

# Báo cáo tối ưu hóa Index – QuickFeed

## 1. Hiện trạng

Bảng `Posts` ban đầu có 5 secondary index: `idx_user_id`, `idx_content`,
`idx_post_type`, `idx_is_visible` và `idx_created_at`. Mỗi index đều phải
được duy trì khi có thao tác ghi dữ liệu. Vì vậy, over-indexing làm tăng
chi phí INSERT/UPDATE/DELETE và sử dụng thêm không gian lưu trữ.

## 2. Chẩn đoán

`idx_content` là prefix B-Tree trên `TEXT` với 255 ký tự. Index này có thể
chiếm nhiều dung lượng và không phải lựa chọn phù hợp cho tìm kiếm toàn văn.
Nếu cần tìm từ khóa trong nội dung, có thể cân nhắc `FULLTEXT`.

`idx_post_type` chỉ có khoảng 3 giá trị và `idx_is_visible` chỉ có 2 giá trị.
Đây là các cột có cardinality thấp. Với điều kiện chọn ra phần lớn số dòng,
Optimizer có thể thấy Full Table Scan rẻ hơn việc đọc index rồi quay lại
các row trong bảng.

Trong khi đó, `idx_user_id` hữu ích cho truy vấn lấy bài viết theo người dùng,
còn `idx_created_at` hỗ trợ các truy vấn lấy bài viết theo thời gian.

## 3. Giải pháp

Đã DROP 3 index: `idx_content`, `idx_post_type`, `idx_is_visible`.
Giữ lại `idx_user_id` và `idx_created_at`.

Sau khi chạy script, dùng `SHOW TABLE STATUS LIKE 'Posts'` hoặc
`information_schema.TABLES` để ghi nhận `INDEX_LENGTH` trước và sau tối ưu.

## 4. Đánh đổi Read và Write

Index thường giúp SELECT nhanh hơn nhưng phải trả giá bằng dung lượng và
chi phí duy trì khi ghi. Trong trường hợp QuickFeed có nhiều INSERT bài viết,
việc giữ các index ít chọn lọc làm tăng công việc ghi mà không mang lại lợi
ích truy vấn tương xứng. Sau khi loại bỏ 3 index không phù hợp, mỗi INSERT
không còn phải cập nhật ba secondary B-Tree tương ứng.

## 5. Số liệu thực tế

Điền số liệu sau khi chạy trên máy:

| Chỉ số | Trước tối ưu | Sau tối ưu |
|---|---:|---:|
| Data size (MB) | ___ | ___ |
| Index size (MB) | ___ | ___ |
| Total size (MB) | ___ | ___ |

Lưu ý: với bảng mới hoặc ít dữ liệu, mức giảm dung lượng có thể nhỏ.
Không nên tự ghi số liệu giả; hãy lấy trực tiếp từ MySQL.

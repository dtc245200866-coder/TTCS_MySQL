-- quickfeed_index_optimization.sql
-- HỆ THỐNG QUICKFEED - TỐI ƯU HÓA INDEX
-- Database: quickfeed_db
-- Table: Posts

USE quickfeed_db;

-- ========================================================
-- 1. KIỂM TRA INDEX HIỆN TẠI
-- ========================================================

SHOW INDEX FROM Posts;

-- ========================================================
-- 2. ĐO DUNG LƯỢNG TRƯỚC KHI TỐI ƯU
-- ========================================================

SHOW TABLE STATUS LIKE 'Posts';

SELECT
    TABLE_NAME,
    ROUND(DATA_LENGTH / 1024 / 1024, 2) AS data_size_mb,
    ROUND(INDEX_LENGTH / 1024 / 1024, 2) AS index_size_mb,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS total_size_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'Posts';

-- ========================================================
-- 3. XÓA 3 INDEX KHÔNG HIỆU QUẢ
-- ========================================================

-- Không nên dùng B-Tree prefix index dài cho TEXT nếu mục tiêu
-- là tìm kiếm nội dung. Có thể cân nhắc FULLTEXT khi cần.
ALTER TABLE Posts DROP INDEX idx_content;

-- post_type chỉ có khoảng 3 giá trị => cardinality thấp.
ALTER TABLE Posts DROP INDEX idx_post_type;

-- is_visible chỉ có 2 giá trị => cardinality cực thấp.
ALTER TABLE Posts DROP INDEX idx_is_visible;

-- ========================================================
-- 4. KIỂM TRA LẠI INDEX SAU KHI TỐI ƯU
-- ========================================================

SHOW INDEX FROM Posts;

-- ========================================================
-- 5. ĐO DUNG LƯỢNG SAU KHI TỐI ƯU
-- ========================================================

SHOW TABLE STATUS LIKE 'Posts';

SELECT
    TABLE_NAME,
    ROUND(DATA_LENGTH / 1024 / 1024, 2) AS data_size_mb,
    ROUND(INDEX_LENGTH / 1024 / 1024, 2) AS index_size_mb,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS total_size_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'Posts';

-- ========================================================
-- 6. KIỂM TRA QUERY PLAN (TÙY CHỌN)
-- ========================================================

EXPLAIN SELECT *
FROM Posts
WHERE user_id = 1;

EXPLAIN SELECT *
FROM Posts
ORDER BY created_at DESC
LIMIT 20;

EXPLAIN SELECT *
FROM Posts
WHERE is_visible = 1;

-- ========================================================
-- 7. GỢI Ý NẾU CẦN TÌM KIẾM VĂN BẢN
-- ========================================================

-- Không tạo lại idx_content bằng B-Tree.
-- Nếu yêu cầu tìm kiếm từ khóa trong content:
--
-- ALTER TABLE Posts ADD FULLTEXT INDEX ft_content (content);
--
-- Sau đó có thể dùng:
--
-- SELECT *
-- FROM Posts
-- WHERE MATCH(content) AGAINST ('mysql' IN NATURAL LANGUAGE MODE);
